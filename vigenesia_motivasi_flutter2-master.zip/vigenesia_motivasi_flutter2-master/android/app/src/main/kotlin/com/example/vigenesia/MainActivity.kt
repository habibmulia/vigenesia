package com.example.vigenesia

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
