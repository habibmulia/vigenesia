var url = "http://192.168.8.101";

//pake "/" belakangnya
// ip di ambil dari ipv4 lewat cmd ipconfig pada wifi adapter