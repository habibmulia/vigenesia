import 'package:flutter/material.dart';
// import 'package:vigenesia/Screens/Login.dart';

import 'Screens/Login.dart'; // <-- Main vorlder

void main() => runApp(
  const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Login(), 
  )
);